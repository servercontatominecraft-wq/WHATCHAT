let socket;
let currentUsername = null;
let currentIDG = null;
let friends = [];

document.addEventListener('DOMContentLoaded', function() {
    socket = io();
    setupSocketListeners();
    setupEventListeners();
});

function setupEventListeners() {
    // Enter key to send message
    const msgInput = document.getElementById('msg-input');
    if (msgInput) {
        msgInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });
    }

    // Settings button
    document.getElementById('settings-btn').addEventListener('click', toggleSettings);
    
    // Close modal on background click
    document.getElementById('settings-modal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeSettings();
        }
    });
}

function setupSocketListeners() {
    socket.on('connect', function() {
        console.log('✅ Conectado ao servidor ChatOp');
    });

    socket.on('user_setup', function(data) {
        currentUsername = data.username;
        currentIDG = data.idg;
        document.getElementById('user-name').textContent = currentUsername;
        document.getElementById('idg-display').textContent = currentIDG;
        console.log(`👤 Seu IDG: ${currentIDG}`);
    });

    socket.on('message', function(data) {
        if (data.type === 'text') {
            displayMessage(data);
        }
    });

    socket.on('file_shared', function(data) {
        displayFileMessage(data);
    });

    socket.on('user_joined', function(data) {
        displayNotification(`${data.username} entrou no chat`);
    });

    socket.on('user_left', function(data) {
        displayNotification(`${data.username} saiu do chat`);
    });

    socket.on('friend_added', function(data) {
        displayNotification(`✅ ${data.username} (${data.idg}) adicionado aos amigos!`);
        updateFriendsList();
    });

    socket.on('friend_request', function(data) {
        displayNotification(`👤 ${data.username} adicionou você como amigo! (IDG: ${data.idg})`);
    });

    socket.on('error', function(error) {
        console.error('❌ Erro:', error.message);
        alert('Erro: ' + error.message);
    });

    socket.on('disconnect', function() {
        console.log('❌ Desconectado do servidor');
    });
}

function setUsername() {
    const input = document.getElementById('username-input');
    const username = input.value.trim();
    
    if (username.length === 0) {
        alert('Digite um nome!');
        return;
    }
    
    if (username.length > 30) {
        alert('Nome muito longo! (máximo 30 caracteres)');
        return;
    }
    
    currentUsername = username;
    
    // Hide setup dialog and show chat
    document.getElementById('setup-dialog').classList.add('hidden');
    document.getElementById('messages-container').classList.remove('hidden');
    
    // Notify server
    socket.emit('set_username', { username: username });
    
    // Focus input
    document.getElementById('msg-input').focus();
}

function sendMessage() {
    const input = document.getElementById('msg-input');
    const message = input.value.trim();
    
    if (message.length === 0) return;
    
    socket.emit('message', {
        text: message,
        username: currentUsername,
        idg: currentIDG,
        timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
    });
    
    input.value = '';
    input.focus();
}

function handleFileSelect() {
    const fileInput = document.getElementById('file-input');
    const file = fileInput.files[0];
    
    if (!file) return;
    
    if (file.size > 16 * 1024 * 1024) {
        alert('Arquivo muito grande! (máximo 16MB)');
        fileInput.value = '';
        return;
    }
    
    const reader = new FileReader();
    reader.onload = function(e) {
        socket.emit('file_upload', {
            file: e.target.result,
            filename: file.name,
            username: currentUsername,
            idg: currentIDG,
            timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
        });
        
        fileInput.value = '';
        console.log(`📤 Arquivo enviado: ${file.name}`);
    };
    
    reader.readAsArrayBuffer(file);
}

function displayMessage(data) {
    const messagesDiv = document.getElementById('messages');
    const messageEl = document.createElement('div');
    
    const isOwn = data.username === currentUsername;
    messageEl.className = 'message ' + (isOwn ? 'own' : 'other');
    
    const bubbleHTML = `
        ${isOwn ? '' : '<div class="message-sender">' + data.username + '</div>'}
        <div class="message-bubble">
            <div>${escapeHtml(data.text)}</div>
            <div class="message-time">${data.timestamp}</div>
        </div>
    `;
    
    messageEl.innerHTML = bubbleHTML;
    messagesDiv.appendChild(messageEl);
    
    // Scroll to bottom
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
}

function displayFileMessage(data) {
    const messagesDiv = document.getElementById('messages');
    const messageEl = document.createElement('div');
    
    const isOwn = data.username === currentUsername;
    messageEl.className = 'message ' + (isOwn ? 'own' : 'other');
    
    const bubbleHTML = `
        ${isOwn ? '' : '<div class="message-sender">' + data.username + '</div>'}
        <div class="message-bubble file-message">
            <a href="${data.filepath}" class="file-item" download>
                <span class="file-icon">📎</span>
                <span>${escapeHtml(data.filename)}</span>
            </a>
            <div class="message-time">${data.timestamp}</div>
        </div>
    `;
    
    messageEl.innerHTML = bubbleHTML;
    messagesDiv.appendChild(messageEl);
    
    // Scroll to bottom
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
}

function displayNotification(text) {
    const messagesDiv = document.getElementById('messages');
    const notifEl = document.createElement('div');
    notifEl.className = 'notification';
    notifEl.textContent = text;
    messagesDiv.appendChild(notifEl);
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
}

function toggleSettings() {
    const modal = document.getElementById('settings-modal');
    modal.classList.toggle('hidden');
    updateFriendsList();
}

function closeSettings() {
    document.getElementById('settings-modal').classList.add('hidden');
}

function copyIDG() {
    if (currentIDG) {
        navigator.clipboard.writeText(currentIDG).then(() => {
            alert('✅ IDG copiado para a área de transferência!');
        });
    }
}

function addFriend() {
    const input = document.getElementById('friend-idg-input');
    const idg = input.value.trim();
    
    if (!idg) {
        alert('Digite o IDG do amigo!');
        return;
    }
    
    socket.emit('add_friend', { idg: idg });
    input.value = '';
}

function updateFriendsList() {
    const friendsList = document.getElementById('friends-list');
    
    if (friends.length === 0) {
        friendsList.innerHTML = '<p class="empty">Nenhum amigo adicionado ainda</p>';
    } else {
        let html = '';
        friends.forEach(friend => {
            html += `
                <div class="friend-item ${friend.online ? 'online' : ''}">
                    <div>
                        <div class="friend-item-name">${escapeHtml(friend.username)}</div>
                        <div class="friend-item-idg">${friend.idg}</div>
                    </div>
                </div>
            `;
        });
        friendsList.innerHTML = html;
    }
}

function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}
