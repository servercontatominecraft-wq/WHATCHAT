from flask import Flask, render_template, request
from flask_socketio import SocketIO, emit, send, join_room, leave_room
from datetime import datetime
import random
import string
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size
app.config['UPLOAD_FOLDER'] = 'uploads'

# Create upload folder if it doesn't exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

socketio = SocketIO(app, cors_allowed_origins="*")

# Store connected users with more info
users = {}  # {sid: {username, idg, friends: [sids]}}
users_by_idg = {}  # {idg: sid}
message_history = []
file_counter = 0

@app.route('/')
def index():
    return render_template('index.html')

def generate_idg():
    """Generate a random unique IDG like 637462867"""
    while True:
        idg = ''.join(str(random.randint(0, 9)) for _ in range(9))
        if idg not in users_by_idg:
            return idg

@socketio.on('set_username')
def handle_username(data):
    username = data['username']
    idg = generate_idg()
    
    users[request.sid] = {
        'username': username,
        'idg': idg,
        'friends': [],
        'connected': True
    }
    users_by_idg[idg] = request.sid
    
    # Send user their IDG and connected users
    emit('user_setup', {
        'username': username,
        'idg': idg
    })
    
    emit('user_joined', {
        'username': username,
        'idg': idg,
        'message': f'{username} entrou no chat'
    }, broadcast=True)
    print(f"👤 {username} (IDG: {idg}) entrou no chat")

@socketio.on('add_friend')
def handle_add_friend(data):
    friend_idg = data.get('idg', '').strip()
    
    if friend_idg not in users_by_idg:
        emit('error', {'message': 'IDG não encontrado!'})
        return
    
    friend_sid = users_by_idg[friend_idg]
    if friend_sid == request.sid:
        emit('error', {'message': 'Você não pode adicionar a si mesmo!'})
        return
    
    if friend_sid in users[request.sid]['friends']:
        emit('error', {'message': 'Este amigo já foi adicionado!'})
        return
    
    users[request.sid]['friends'].append(friend_sid)
    friend_user = users[friend_sid]
    
    emit('friend_added', {
        'username': friend_user['username'],
        'idg': friend_user['idg']
    })
    
    # Notify friend
    emit('friend_request', {
        'username': users[request.sid]['username'],
        'idg': users[request.sid]['idg']
    }, to=friend_sid)
    
    print(f"➕ {users[request.sid]['username']} adicionou {friend_user['username']}")

@socketio.on('message')
def handle_message(data):
    msg_data = {
        'username': data.get('username', 'Anônimo'),
        'text': data.get('text', ''),
        'timestamp': data.get('timestamp', datetime.now().strftime('%H:%M')),
        'idg': data.get('idg', ''),
        'type': 'text'
    }
    
    message_history.append(msg_data)
    emit('message', msg_data, broadcast=True)
    print(f"💬 [{msg_data['username']}]: {msg_data['text']}")

@socketio.on('file_upload')
def handle_file_upload(data):
    file_data = data.get('file')
    filename = data.get('filename', 'file')
    username = data.get('username', 'Anônimo')
    
    if not file_data:
        emit('error', {'message': 'Arquivo vazio!'})
        return
    
    try:
        safe_name = secure_filename(filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], f"{request.sid}_{safe_name}")
        
        # Save file
        with open(filepath, 'wb') as f:
            f.write(file_data)
        
        file_msg = {
            'username': username,
            'filename': safe_name,
            'filepath': filepath,
            'timestamp': datetime.now().strftime('%H:%M'),
            'idg': data.get('idg', ''),
            'type': 'file'
        }
        
        message_history.append(file_msg)
        emit('file_shared', file_msg, broadcast=True)
        print(f"📁 [{username}] enviou: {safe_name}")
    except Exception as e:
        emit('error', {'message': str(e)})

@socketio.on('connect')
def handle_connect():
    print(f"✅ Usuário conectado: {request.sid}")

@socketio.on('disconnect')
def handle_disconnect():
    if request.sid in users:
        user_data = users[request.sid]
        username = user_data['username']
        idg = user_data['idg']
        
        if idg in users_by_idg:
            del users_by_idg[idg]
        del users[request.sid]
        
        emit('user_left', {
            'username': username,
            'idg': idg,
            'message': f'{username} saiu do chat'
        }, broadcast=True)
        print(f"👤 {username} (IDG: {idg}) saiu do chat")

if __name__ == '__main__':
    print("🚀 Servidor ChatOp iniciado em http://localhost:5000")
    socketio.run(app, host='0.0.0.0', port=5000, debug=True)